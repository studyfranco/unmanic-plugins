**<span style="color:#56adda">0.0.3</span>**
- Add some feature who are usefull when you clean your library !

**<span style="color:#56adda">0.0.1</span>**
- initial version