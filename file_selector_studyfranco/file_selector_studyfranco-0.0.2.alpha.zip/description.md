
---

##### Links:

- [Support](https://unmanic.app/discord)
- [Issues/Feature Requests](https://github.com/Unmanic/plugin.mover2/issues)
- [Pull Requests](https://github.com/Unmanic/plugin.mover2/pulls)

---

##### Documentation:

##### Config description:

---

##### Examples:

###### Result:

###### Result: